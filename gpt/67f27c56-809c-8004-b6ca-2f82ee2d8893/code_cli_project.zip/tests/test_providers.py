# Tests for AI providers
