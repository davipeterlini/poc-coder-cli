# Tests for CLI
