# Tools for bash command integration
