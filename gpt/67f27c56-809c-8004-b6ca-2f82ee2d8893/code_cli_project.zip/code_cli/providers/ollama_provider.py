# Ollama local integration
