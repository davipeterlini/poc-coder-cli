# OpenAI integration
