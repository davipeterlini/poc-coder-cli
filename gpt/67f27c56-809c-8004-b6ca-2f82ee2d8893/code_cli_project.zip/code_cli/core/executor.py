# Execution planning and execution logic
